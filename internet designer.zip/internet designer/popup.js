const textInput = document.getElementById('textInput');
const addTextBtn = document.getElementById('addTextBtn');
const imageInput = document.getElementById('imageInput');
const textListDiv = document.getElementById('textList');
const imageListDiv = document.getElementById('imageList');
const clearBtn = document.getElementById('clearBtn');

const pluginToggle = document.getElementById('pluginToggle');
const togglePrintBtn = document.getElementById('togglePrintBtn');
const remixSlider = document.getElementById('remixSlider');
const sliderValue = document.getElementById('sliderValue');

const loopSlider = document.getElementById('loopSlider');
const loopValue = document.getElementById('loopValue');

// Initiales Laden aller Daten und Zustände
chrome.storage.local.get({ 
  savedTexts: [], 
  savedImages: [], 
  remixFactor: 0,
  maxLoops: 101, 
  isActive: true,
  isPrintMode: false
}, (data) => {
  remixSlider.value = data.remixFactor;
  sliderValue.innerText = data.remixFactor;
  
  loopSlider.value = data.maxLoops;
  loopValue.innerText = data.maxLoops > 100 ? "✶" : data.maxLoops;
  
  pluginToggle.checked = data.isActive;
  updatePrintButtonUI(data.isPrintMode);
  updateLists();
});

// GEÄNDERT: Akzeptiert jetzt ein Option-Objekt für den Reload-Befehl
function notifyTab(options = {}) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, { 
        action: "reapply", 
        reload: options.reload || false 
      }).catch(() => {});
    }
  });
}

pluginToggle.addEventListener('change', () => {
  const newState = pluginToggle.checked;
  chrome.storage.local.set({ isActive: newState }, () => {
    notifyTab({ reload: true }); // Reload beim Ein-/Ausschalten des Plugins
  });
});

togglePrintBtn.addEventListener('click', () => {
  chrome.storage.local.get({ isPrintMode: false }, (data) => {
    const newState = !data.isPrintMode;
    chrome.storage.local.set({ isPrintMode: newState }, () => {
      updatePrintButtonUI(newState);
      notifyTab({ reload: false }); // KEIN Reload beim Umschalten der Druckansicht
    });
  });
});

function updatePrintButtonUI(isPrintMode) {
  if (isPrintMode) {
    togglePrintBtn.innerText = "printview: on";
    togglePrintBtn.className = "active";
  } else {
    togglePrintBtn.innerText = "printview: off";
    togglePrintBtn.className = "";
  }
}

addTextBtn.addEventListener('click', () => {
  const text = textInput.value.trim();
  if (text) {
    addItem('savedTexts', text);
    textInput.value = '';
  }
});

imageInput.addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = function(event) {
      addItem('savedImages', event.target.result);
      imageInput.value = '';
    };
    reader.readAsDataURL(file);
  }
});

function addItem(storageKey, value) {
  chrome.storage.local.get({ [storageKey]: [] }, (data) => {
    const list = data[storageKey];
    list.push(value);
    chrome.storage.local.set({ [storageKey]: list }, () => {
      updateLists();
      notifyTab({ reload: true }); // Reload bei neuem Eintrag im Pool
    });
  });
}

function updateLists() {
  renderSingleList('savedTexts', textListDiv, 'text');
  renderSingleList('savedImages', imageListDiv, 'image');
}

function renderSingleList(storageKey, containerDiv, type) {
  chrome.storage.local.get({ [storageKey]: [] }, (data) => {
    containerDiv.innerHTML = '';
    const list = data[storageKey];

    list.forEach((value, index) => {
      const itemDiv = document.createElement('div');
      itemDiv.className = 'item';
      itemDiv.draggable = true;
      itemDiv.dataset.index = index;

      if (type === 'text') {
        itemDiv.innerText = `${index + 1}. ${value}`;
      } else {
        itemDiv.innerHTML = `${index + 1}. <img src="${value}">`;
      }

      const delBtn = document.createElement('button');
      delBtn.innerText = '×';
      delBtn.className = 'delete-btn';
      delBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        deleteItem(storageKey, index);
      });
      itemDiv.appendChild(delBtn);

      itemDiv.addEventListener('dragstart', (e) => {
        e.dataTransfer.setData('text/plain', index);
        e.dataTransfer.setData('sourceKey', storageKey);
      });

      itemDiv.addEventListener('dragover', (e) => { e.preventDefault(); });

      itemDiv.addEventListener('drop', (e) => {
        e.preventDefault();
        const fromIndex = parseInt(e.dataTransfer.getData('text/plain'), 10);
        const sourceKey = e.dataTransfer.getData('sourceKey');
        const toIndex = index;

        if (sourceKey === storageKey && fromIndex !== toIndex) {
          const movedItem = list.splice(fromIndex, 1)[0];
          list.splice(toIndex, 0, movedItem);
          chrome.storage.local.set({ [storageKey]: list }, () => {
            updateLists();
            notifyTab({ reload: true }); // Reload nach dem Verschieben per Drag & Drop
          });
        }
      });

      containerDiv.appendChild(itemDiv);
    });
  });
}

function deleteItem(storageKey, index) {
  chrome.storage.local.get({ [storageKey]: [] }, (data) => {
    const list = data[storageKey];
    list.splice(index, 1);
    chrome.storage.local.set({ [storageKey]: list }, () => {
      updateLists();
      notifyTab({ reload: true }); // Reload nach dem Löschen eines Eintrags
    });
  });
}

clearBtn.addEventListener('click', () => {
  chrome.storage.local.set({ savedTexts: [], savedImages: [] }, () => {
    updateLists();
    notifyTab({ reload: true }); // Reload nach dem Leeren des Pools
  });
});

remixSlider.addEventListener('input', (e) => {
  const value = parseInt(e.target.value, 10);
  sliderValue.innerText = value;
  chrome.storage.local.set({ remixFactor: value }, () => {
    notifyTab({ reload: true }); // Reload bei Änderung des Remix-Faktors
  });
});

loopSlider.addEventListener('input', (e) => {
  const value = parseInt(e.target.value, 10);
  loopValue.innerText = value > 100 ? "✶" : value;
  chrome.storage.local.set({ maxLoops: value }, () => {
    notifyTab({ reload: true }); // Reload bei Änderung der Loops
  });
});