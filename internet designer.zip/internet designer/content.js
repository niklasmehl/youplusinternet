function processPage() {
  chrome.storage.local.get({ 
    isActive: true, 
    isPrintMode: false,
    savedTexts: [], 
    savedImages: [], 
    collectedStyles: [], 
    remixFactor: 0,
    maxLoops: 101
  }, (data) => {
    
    if (!data.isActive) {
      document.body.classList.remove('plugin-print-preview');
      removeEditButtons();
      return;
    }

    ensurePrintStyles();

    if (data.isPrintMode) {
      document.body.classList.add('plugin-print-preview');
    } else {
      document.body.classList.remove('plugin-print-preview');
    }
    
    const savedTexts = data.savedTexts;
    const savedImages = data.savedImages;
    let collectedStyles = data.collectedStyles;
    const remixFactor = data.remixFactor / 100;
    const isInfinite = data.maxLoops > 100;
    const maxLoops = data.maxLoops;

    let totalTextsPlaced = 0;
    let totalImagesPlaced = 0;
    let textIndex = 0;
    let imgIndex = 0;
    const MIN_WIDTH = 30;
    const MIN_HEIGHT = 30;

    function isNodeVisible(node) {
      const parent = node.parentElement;
      if (!parent) return false;
      const ignoredTags = ['SCRIPT', 'STYLE', 'HEAD', 'NOSCRIPT', 'TEMPLATE', 'TEXTAREA', 'INPUT', 'BUTTON'];
      if (ignoredTags.includes(parent.tagName) || parent.classList.contains('plugin-edit-btn') || parent.classList.contains('plugin-img-btn')) return false;
      const style = window.getComputedStyle(parent);
      return !(style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0');
    }

    const allElements = document.getElementsByTagName('*');
    let addedCount = 0;
    
    for (let i = 0; i < allElements.length && addedCount < 15; i++) {
      const el = allElements[Math.floor(Math.random() * allElements.length)];
      if (el && el.innerText && el.innerText.trim().length > 0 && !el.classList.contains('plugin-edit-btn') && !el.classList.contains('plugin-img-btn')) {
        const style = window.getComputedStyle(el);
        
        const candidate = {
          fontFamily: style.fontFamily,
          fontSize: style.fontSize,
          color: style.color,
          textAlign: style.textAlign
        };

        const isDuplicate = collectedStyles.some(s => 
          s.fontFamily === candidate.fontFamily &&
          s.fontSize === candidate.fontSize &&
          s.color === candidate.color &&
          s.textAlign === candidate.textAlign
        );

        if (!isDuplicate) {
          collectedStyles.push(candidate);
          addedCount++;
          if (collectedStyles.length > 500) { collectedStyles.shift(); }
        }
      }
    }

    if (addedCount > 0) {
      chrome.storage.local.set({ collectedStyles: collectedStyles });
    }

    // --- 2. TEXTE ERSETZEN & EDIT-BUTTONS ANBRINGEN ---
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
    let textNode;
    
    while ((textNode = walker.nextNode())) {
      if (textNode.nodeValue.trim().length > 0 && isNodeVisible(textNode)) {
        const parent = textNode.parentElement;

        if (parent.closest('[data-is-manually-edited="true"]')) continue;

        if (!parent.dataset.hasEditBtn && parent.tagName !== 'BODY') {
          addEditButtonTo(parent, textNode);
        }

        if (savedTexts.length > 0 && !savedTexts.includes(textNode.nodeValue)) {
          const maxAllowedTexts = savedTexts.length * maxLoops;
          
          if (isInfinite || totalTextsPlaced < maxAllowedTexts) {
            textNode.nodeValue = savedTexts[textIndex];
            textIndex = (textIndex + 1) % savedTexts.length;
            totalTextsPlaced++;
          } else {
            textNode.nodeValue = "\u00A0"; 
          }
        }

        if (collectedStyles.length > 0 && !parent.dataset.isRemixed) {
          if (Math.random() < remixFactor) {
            const randomStyle = collectedStyles[Math.floor(Math.random() * collectedStyles.length)];
            parent.style.fontFamily = randomStyle.fontFamily;
            parent.style.fontSize = randomStyle.fontSize;
            parent.style.color = randomStyle.color;
            parent.style.textAlign = randomStyle.textAlign;
          }
          parent.dataset.isRemixed = "true";
        }
      }
    }

    // --- 3. BILDER ERSETZEN & BILD-EDIT-BUTTONS ANBRINGEN ---
    for (let i = 0; i < allElements.length; i++) {
      const el = allElements[i];
      if (el.classList.contains('plugin-edit-btn') || el.classList.contains('plugin-img-btn') || el.classList.contains('plugin-img-wrapper')) continue;
      
      const rect = el.getBoundingClientRect();
      const originalWidth = el.clientWidth || rect.width || parseInt(el.style.width) || 0;
      const originalHeight = el.clientHeight || rect.height || parseInt(el.style.height) || 0;

      if (originalWidth < MIN_WIDTH || originalHeight < MIN_HEIGHT) continue;

      const isImgTag = el.tagName.toLowerCase() === 'img';
      let hasBackgroundImage = false;
      let computedStyle = null;

      if (!isImgTag) {
        computedStyle = window.getComputedStyle(el);
        const bgImg = computedStyle.backgroundImage;
        if (bgImg && bgImg !== 'none' && bgImg.startsWith('url')) {
          
          hasBackgroundImage = true;
        }
      }

      if (!isImgTag && !hasBackgroundImage) continue;

      if (!el.dataset.hasImgBtn && !el.closest('.plugin-img-wrapper')) {
        addImageEditButtonTo(el, isImgTag);
      }

      if (el.closest('[data-is-manually-edited="true"]')) continue;

      if (savedImages.length > 0) {
        const maxAllowedImages = savedImages.length * maxLoops;

        if (isInfinite || totalImagesPlaced < maxAllowedImages) {
          if (isImgTag) {
            if (savedImages.includes(el.src)) { totalImagesPlaced++; continue; }
            if (el.hasAttribute('srcset')) el.removeAttribute('srcset');
            el.src = savedImages[imgIndex];
            if (originalWidth > 0) el.style.width = originalWidth + 'px';
            if (originalHeight > 0) el.style.height = originalHeight + 'px';
            el.style.objectFit = 'cover';
          } else if (hasBackgroundImage) {
            const currentBg = computedStyle.backgroundImage;
            if (savedImages.some(img => currentBg.includes(img))) { totalImagesPlaced++; continue; }
            el.style.backgroundImage = `url("${savedImages[imgIndex]}")`;
            el.style.backgroundSize = 'cover';
            el.style.backgroundPosition = 'center';
          }
          imgIndex = (imgIndex + 1) % savedImages.length;
          totalImagesPlaced++;
        } else {
          if (isImgTag) {
            el.src = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg'/>";
            el.style.opacity = "0";
          } else if (hasBackgroundImage) {
            el.style.backgroundImage = "none";
          }
        }
      }
    }
  });
}

function addEditButtonTo(parent, textNode) {
  parent.dataset.hasEditBtn = "true";
  
  const currentPos = window.getComputedStyle(parent).position;
  if (currentPos === 'static') {
    parent.style.position = 'relative';
  }

  const btn = document.createElement('button');
  btn.innerText = '✎';
  btn.className = 'plugin-edit-btn';
  btn.title = 'edit text directly';
  btn.contentEditable = "false"; 
  
  btn.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    
    parent.dataset.isManuallyEdited = "true";
    parent.classList.add('plugin-is-editing'); // NEU: CSS-Klasse zur Layout-Stabilisierung
    btn.style.opacity = "0";
    btn.style.pointerEvents = "none";
    parent.contentEditable = "true";
    parent.focus();
    
    // KORREKTUR: Robusterer Check direkt auf Text Content per MutationObserver/Keydown Alternative
    parent.addEventListener('input', () => {
      // Wenn gar kein Text oder nur Whitespaces übrig sind
      if (parent.textContent.replace(/✎/g, '').trim() === "") {
        parent.innerHTML = "\u00A0"; // Erzwinge ein unzerstörbares geschütztes Leerzeichen
        
        // Cursor stabilisieren
        const range = document.createRange();
        const sel = window.getSelection();
        range.selectNodeContents(parent);
        range.collapse(false);
        sel.removeAllRanges();
        sel.addRange(range);
      }
    });
    
    parent.addEventListener('blur', () => {
      parent.contentEditable = "false";
      parent.classList.remove('plugin-is-editing');
      btn.style.opacity = ""; 
      btn.style.pointerEvents = "";
      
      if (parent.textContent.replace(/✎/g, '').trim() === "") {
        parent.innerHTML = "\u00A0";
      }
    }, { once: true });
  });

  parent.appendChild(btn);
}

function addImageEditButtonTo(element, isImgTag) {
  element.dataset.hasImgBtn = "true";

  const wrapper = document.createElement('div');
  wrapper.className = 'plugin-img-wrapper';
  wrapper.style.position = 'relative';
  wrapper.style.display = window.getComputedStyle(element).display === 'block' ? 'block' : 'inline-block';
  
  element.parentNode.insertBefore(wrapper, element);
  wrapper.appendChild(element);

  const fileInput = document.createElement('input');
  fileInput.type = 'file';
  fileInput.accept = 'image/*';
  fileInput.className = 'plugin-img-btn'; 
  fileInput.title = 'swap image';
  fileInput.style.color = 'transparent'; 

  element.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
  }, true);

  fileInput.addEventListener('click', (e) => {
    e.stopPropagation(); 
  });

  fileInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        element.dataset.isManuallyEdited = "true";
        
        if (isImgTag) {
          if (element.hasAttribute('srcset')) element.removeAttribute('srcset');
          element.src = event.target.result;
          element.style.objectFit = 'cover';
        } else {
          element.style.backgroundImage = `url("${event.target.result}")`;
          element.style.backgroundSize = 'cover';
          element.style.backgroundPosition = 'center';
        }
      };
      reader.readAsDataURL(file);
    }
  });

  wrapper.appendChild(fileInput);
}

function removeEditButtons() {
  const editButtons = document.querySelectorAll('.plugin-edit-btn, .plugin-img-btn');
  editButtons.forEach(b => b.remove());
  
  const wrappers = document.querySelectorAll('.plugin-img-wrapper');
  wrappers.forEach(w => {
    if (w.parentNode) {
      while (w.firstChild) {
        if (w.firstChild.nodeName !== 'BUTTON' && w.firstChild.nodeName !== 'INPUT') {
          if (w.firstChild.style) {
            w.firstChild.style.pointerEvents = '';
          }
          w.parentNode.insertBefore(w.firstChild, w);
        } else {
          w.removeChild(w.firstChild);
        }
      }
      w.parentNode.removeChild(w);
    }
  });

  const markedElements = document.querySelectorAll('[data-has-edit-btn], [data-has-img-btn]');
  markedElements.forEach(el => {
    delete el.dataset.hasEditBtn;
    delete el.dataset.hasImgBtn;
    delete el.dataset.isManuallyEdited;
    el.classList.remove('plugin-is-editing');
  });
}

function ensurePrintStyles() {
  if (document.getElementById('plugin-print-styles')) return;

  const styleEl = document.createElement('style');
  styleEl.id = 'plugin-print-styles';
  styleEl.innerHTML = `
    .plugin-edit-btn {
      position: absolute !important;
      top: 2px !important;
      right: 2px !important;
      background: #000000 !important;
      color: #ffffff !important;
      border: none !important;
      border-radius: 0px !important;
      cursor: pointer !important;
      font-family: ui-monospace, monospace !important;
      font-size: 10px !important;
      padding: 2px 4px !important;
      z-index: 99999 !important;
      opacity: 0.2 !important;
      transition: opacity 0.15s ease !important;
    }
    
    .plugin-img-btn {
      position: absolute !important;
      top: 2px !important;
      right: 2px !important;
      background: #000000 !important;
      border: none !important;
      border-radius: 0px !important;
      cursor: pointer !important;
      z-index: 99999 !important;
      opacity: 0.2 !important;
      transition: opacity 0.15s ease !important;
      width: 18px !important;
      height: 15px !important;
      overflow: hidden !important;
      padding: 0 !important;
    }
    
    .plugin-img-btn::before {
      content: '⎚' !important;
      position: absolute !important;
      left: 4px !important;
      top: 1px !important;
      font-family: ui-monospace, monospace !important;
      font-size: 10px !important;
      color: #ffffff !important;
    }
    
    .plugin-img-btn::-webkit-file-upload-button {
      visibility: hidden !important;
      width: 0 !important;
      padding: 0 !important;
    }
    
    *:hover > .plugin-edit-btn,
    .plugin-img-wrapper:hover > .plugin-img-btn {
      opacity: 1 !important;
    }

    body.plugin-print-preview {
      background: #525659 !important; 
      padding: 30px 10px !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
    }

    body.plugin-print-preview > * {
      background: white !important;
      color: black !important;
      box-shadow: 0 0 15px rgba(0,0,0,0.4) !important;
      max-width: 21cm !important; 
      width: 100% !important;
      margin-bottom: 20px !important;
      box-sizing: border-box !important;
    }

    body.plugin-print-preview * {
      word-break: break-word !important;
      overflow-wrap: break-word !important;
    }

    /* KORREKTUR: Brutale Stabilisierung des Layouts im aktiven Bearbeitungsmodus */
    .plugin-is-editing, .plugin-is-editing * {
      min-height: 1.5em !important;
      min-width: 40px !important;
      display: inline-block !important;
      outline: 1px dashed rgba(0, 0, 0, 0.4) !important;
      background: rgba(0, 0, 0, 0.03) !important;
    }

    .plugin-edit-btn {
      pointer-events: auto !important;
    }

    @media print {
      .plugin-edit-btn, .plugin-img-btn,
      body .plugin-edit-btn, body .plugin-img-btn,
      body.plugin-print-preview .plugin-edit-btn, body.plugin-print-preview .plugin-img-btn {
        display: none !important;
        visibility: hidden !important;
        opacity: 0 !important;
      }

      body.plugin-print-preview {
        background: white !important;
        padding: 0 !important;
        display: block !important;
      }

      body.plugin-print-preview > * {
        background: transparent !important;
        box-shadow: none !important;
        max-width: 100% !important;
        width: 100% !important;
        margin: 0 !important;
      }

      * {
        word-break: break-word !important;
        overflow-wrap: break-word !important;
        max-width: 100% !important;
      }

      img {
        page-break-inside: avoid !important;
        max-height: 100% !important;
      }
    }
  `;
  document.head.appendChild(styleEl);
}

// --- EVENTS ---
processPage();

let timeout = null;
function triggerWithDelay() {
  clearTimeout(timeout);
  timeout = setTimeout(processPage, 250);
}

window.addEventListener('scroll', triggerWithDelay);
window.addEventListener('click', triggerWithDelay);

const observer = new MutationObserver(() => triggerWithDelay());
observer.observe(document.body, { childList: true, subtree: true });

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "reapply") {
    if (request.reload) {
      window.location.reload(); 
    } else {
      processPage(); 
    }
  }
});