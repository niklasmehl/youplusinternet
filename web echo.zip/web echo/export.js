document.addEventListener('DOMContentLoaded', () => {
  // Das Datum jetzt sauber per JavaScript setzen
  document.getElementById('export-date').innerText = new Date().toLocaleDateString('de-DE');

  // Daten und Pinselfarbe aus dem Chrome Storage holen
  chrome.storage.local.get(['globalTextNotes', 'globalOverlays', 'brushColor'], (result) => {
    const notes = result.globalTextNotes || [];
    const overlays = result.globalOverlays || [];
    const brushColor = result.brushColor || '#00ffc8';

    // Setze die Akzentfarbe dynamisch im CSS
    document.documentElement.style.setProperty('--export-accent-color', brushColor);

    const notesContainer = document.getElementById('notes-container');
    const sketchesContainer = document.getElementById('sketches-container');

    // 1. Notizen rendern
    if (notes.length === 0) {
      notesContainer.innerHTML = '<p class="empty-msg">Keine Notizen vorhanden.</p>';
    } else {
      notes.forEach((note) => {
        const row = document.createElement('div');
        row.className = 'note-row';
        row.innerHTML = `<div class="note-text">${escapeHtml(note)}</div>`;
        notesContainer.appendChild(row);
      });
    }

    // 2. Skizzen im nahtlosen 4er-Grid rendern
    if (overlays.length === 0) {
      sketchesContainer.innerHTML = '<p class="empty-msg">Keine Skizzen vorhanden.</p>';
    } else {
      overlays.forEach((imgData) => {
        const item = document.createElement('div');
        item.className = 'sketch-item';
        item.innerHTML = `<img src="${imgData}" class="sketch-img" />`;
        sketchesContainer.appendChild(item);
      });
    }

    // 3. Druckdialog öffnen
    setTimeout(() => {
      window.print();
    }, 500);
  });
});

// Hilfsfunktion gegen HTML-Injektionen
function escapeHtml(text) {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}