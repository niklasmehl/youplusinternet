// Neue Steuerungselemente (togglePlugin ist jetzt eine Checkbox!)
const toggleBtn = document.getElementById('togglePlugin');
const exportBtn = document.getElementById('exportPDF');

// Pinsel-Elemente
const colorPicker = document.getElementById('brushColor');
const sizeSlider = document.getElementById('brushSize');
const sizeVal = document.getElementById('sizeVal');
const glowSizeSlider = document.getElementById('glowSize');
const glowSizeVal = document.getElementById('glowSizeVal');

// Elemente für Bilder & Texte
const imgChanceSlider = document.getElementById('imgChance');
const imgChanceVal = document.getElementById('imgChanceVal');
const imgLoadChanceSlider = document.getElementById('imgLoadChance');
const imgLoadChanceVal = document.getElementById('imgLoadChanceVal');
const textChanceSlider = document.getElementById('textChance');
const textChanceVal = document.getElementById('textChanceVal');
const textLoadChanceSlider = document.getElementById('textLoadChance');
const textLoadChanceVal = document.getElementById('textLoadChanceVal');

// Beim Öffnen des Popups alle alten Werte laden
chrome.storage.local.get([
  'pluginActive', 'brushColor', 'brushSize', 'glowSize',
  'imgChance', 'imgLoadChance', 'textChance', 'textLoadChance'
], (result) => {
  // Plugin-Status laden (Standardmäßig auf 'true', wenn noch nie gesetzt)
  if (result.pluginActive !== undefined) {
    toggleBtn.checked = result.pluginActive;
  } else {
    toggleBtn.checked = true;
  }

  if (result.brushColor) colorPicker.value = result.brushColor;
  if (result.brushSize) {
    sizeSlider.value = result.brushSize;
    sizeVal.innerText = result.brushSize + "px";
  }
  if (result.glowSize !== undefined) {
    glowSizeSlider.value = result.glowSize;
    glowSizeVal.innerText = result.glowSize + "px";
  }
  if (result.imgChance !== undefined) {
    imgChanceSlider.value = result.imgChance;
    imgChanceVal.innerText = result.imgChance + "%";
  }
  if (result.imgLoadChance !== undefined) {
    imgLoadChanceSlider.value = result.imgLoadChance;
    imgLoadChanceVal.innerText = result.imgLoadChance + "%";
  }
  if (result.textChance !== undefined) {
    textChanceSlider.value = result.textChance;
    textChanceVal.innerText = result.textChance + "%";
  }
  if (result.textLoadChance !== undefined) {
    textLoadChanceSlider.value = result.textLoadChance;
    textLoadChanceVal.innerText = result.textLoadChance + "%";
  }
});

// Plugin Aktivieren / Deaktivieren via Slider-Checkbox
toggleBtn.addEventListener('change', () => {
  const isPluginActive = toggleBtn.checked;
  
  chrome.storage.local.set({ pluginActive: isPluginActive }, () => {
    // Aktuelle Seite neu laden, um Änderungen sofort sichtbar zu machen
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs[0] && tabs[0].id) {
        chrome.tabs.reload(tabs[0].id);
      }
    });
  });
});

// PDF EXPORT LOGIK
exportBtn.addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('export.html') });
});

// Restliche Event-Listener (Pinsel & Chancen)
colorPicker.addEventListener('input', (e) => { chrome.storage.local.set({ brushColor: e.target.value }); });
sizeSlider.addEventListener('input', (e) => {
  sizeVal.innerText = e.target.value + "px";
  chrome.storage.local.set({ brushSize: parseInt(e.target.value) });
});
glowSizeSlider.addEventListener('input', (e) => {
  glowSizeVal.innerText = e.target.value + "px";
  chrome.storage.local.set({ glowSize: parseInt(e.target.value) });
});
imgChanceSlider.addEventListener('input', (e) => {
  imgChanceVal.innerText = e.target.value + "%";
  chrome.storage.local.set({ imgChance: parseInt(e.target.value) });
});
imgLoadChanceSlider.addEventListener('input', (e) => {
  imgLoadChanceVal.innerText = e.target.value + "%";
  chrome.storage.local.set({ imgLoadChance: parseInt(e.target.value) });
});
textChanceSlider.addEventListener('input', (e) => {
  textChanceVal.innerText = e.target.value + "%";
  chrome.storage.local.set({ textChance: parseInt(e.target.value) });
});
textLoadChanceSlider.addEventListener('input', (e) => {
  textLoadChanceVal.innerText = e.target.value + "%";
  chrome.storage.local.set({ textLoadChance: parseInt(e.target.value) });
});