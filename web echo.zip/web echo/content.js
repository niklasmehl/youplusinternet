window.addEventListener('load', () => {
  
  // Zuerst prüfen, ob das Plugin aktiv geschaltet ist
  chrome.storage.local.get(['pluginActive'], (status) => {
    // Wenn explizit auf false gesetzt, tun wir nichts!
    if (status.pluginActive === false) {
      console.log("Sketch & Note Plugin ist deaktiviert.");
      return; 
    }

    // Falls aktiv (oder noch nicht gesetzt), führen wir das Plugin normal aus:
    initGlowStyles();
    initPluginLogic();
  });
});

function initPluginLogic() {
  // --- 1. BILDER-LOGIK ---
  const images = document.querySelectorAll('img');
  
  chrome.storage.local.get(['globalOverlays', 'imgChance', 'imgLoadChance'], (result) => {
    const overlayList = result.globalOverlays || [];
    const imgChance = result.imgChance !== undefined ? result.imgChance / 100 : 0.10; 
    const imgLoadChance = result.imgLoadChance !== undefined ? result.imgLoadChance / 100 : 0.40;

    images.forEach((img) => {
      if (img.clientWidth < 100 || img.clientHeight < 100) return;
      
      if (Math.random() <= imgChance) {
        img.classList.add('glow-image');
        img.style.pointerEvents = 'none';
        
        const parentLink = img.closest('a');
        if (parentLink) parentLink.addEventListener('click', (e) => e.preventDefault());

        let dataToLoad = null;
        if (overlayList.length > 0 && Math.random() <= imgLoadChance) {
          const randomIndex = Math.floor(Math.random() * overlayList.length);
          dataToLoad = overlayList[randomIndex];
        }
        
        setTimeout(() => {
          setupAbsoluteSketchLayer(img, dataToLoad);
        }, 500);
      }
    });
  });

  // --- 2. TEXTELEMENT-LOGIK ---
  const textElements = document.querySelectorAll('p, h1, h2, h3, li, article');
  
  chrome.storage.local.get(['globalTextNotes', 'textChance', 'textLoadChance'], (result) => {
    const textNotesList = result.globalTextNotes || [];
    const textChance = result.textChance !== undefined ? result.textChance / 100 : 0.05;
    const textLoadChance = result.textLoadChance !== undefined ? result.textLoadChance / 100 : 0.30;

    textElements.forEach((textEl) => {
      if (textEl.innerText.trim().length < 10) return;
      
      if (Math.random() <= textChance) {
        let textToLoad = "";
        let loadedIndex = null; 

        if (textNotesList.length > 0 && Math.random() <= textLoadChance) {
          const randomIndex = Math.floor(Math.random() * textNotesList.length);
          textToLoad = textNotesList[randomIndex];
          loadedIndex = randomIndex; 
        }
        
        setupTextNoteLayer(textEl, textToLoad, loadedIndex);
      }
    });
  });
}

// --- DYNAMISCHE GLOW-STYLES STEUERUNG ---
function initGlowStyles() {
  const applyStyles = (color, size) => {
    const glowColor = color || '#00ffc8';
    const glowSize = size !== undefined ? size : 50;
    
    document.documentElement.style.setProperty('--dynamic-glow-color', glowColor);
    document.documentElement.style.setProperty('--dynamic-glow-size', `${glowSize}px`);
  };

  chrome.storage.local.get(['brushColor', 'glowSize'], (result) => {
    applyStyles(result.brushColor, result.glowSize);
  });

  chrome.storage.onChanged.addListener(() => {
    chrome.storage.local.get(['brushColor', 'glowSize'], (result) => {
      applyStyles(result.brushColor, result.glowSize);
    });
  });
}

// --- ABSOLUTE SKETCH-LAYER FUNKTION ---
function setupAbsoluteSketchLayer(img, dataToLoad) {
  const outerContainer = document.createElement('div');
  outerContainer.className = 'sketch-outer-container';
  outerContainer.style.width = `${img.clientWidth}px`;
  document.body.appendChild(outerContainer);

  function updatePosition() {
    const rect = img.getBoundingClientRect();
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;
    
    outerContainer.style.top = `${rect.top + scrollTop}px`;
    outerContainer.style.left = `${rect.left + scrollLeft}px`;
    outerContainer.style.width = `${img.clientWidth}px`;
  }

  updatePosition();
  window.addEventListener('scroll', updatePosition, { passive: true });
  window.addEventListener('resize', updatePosition, { passive: true });

  const absoluteWrapper = document.createElement('div');
  absoluteWrapper.className = 'absolute-sketch-wrapper';
  absoluteWrapper.style.width = `${img.clientWidth}px`;
  absoluteWrapper.style.height = `${img.clientHeight}px`;
  outerContainer.appendChild(absoluteWrapper);

  const saveBtn = document.createElement('button');
  saveBtn.className = 'save-sketch-btn external-btn';
  saveBtn.innerText = '✴';
  outerContainer.appendChild(saveBtn);

  const sketch = (p) => {
    let canvas, pg;
    let currentSize = 5;
    let currentColor = '#000000';

    p.setup = () => {
      canvas = p.createCanvas(img.clientWidth, img.clientHeight);
      canvas.addClass('sketch-canvas');
      
      pg = p.createGraphics(img.clientWidth, img.clientHeight);
      pg.clear();
      pg.rectMode(p.CENTER);
      pg.noStroke();

      if (dataToLoad) {
        p.loadImage(dataToLoad, (loadedImg) => {
          pg.image(loadedImg, 0, 0, img.clientWidth, img.clientHeight);
        });
      }

      chrome.storage.local.get(['brushColor', 'brushSize'], (result) => {
        if (result.brushColor) currentColor = result.brushColor;
        if (result.brushSize) currentSize = result.brushSize;
      });

      chrome.storage.onChanged.addListener((changes) => {
        if (changes.brushColor) currentColor = changes.brushColor.newValue;
        if (changes.brushSize) currentSize = changes.brushSize.newValue;
      });
    };

    p.draw = () => {
      p.clear();
      p.image(pg, 0, 0);
      
      if (p.mouseIsPressed && p.mouseX >= 0 && p.mouseX <= p.width && p.mouseY >= 0 && p.mouseY <= p.height) {
        pg.fill(currentColor);
        pg.rect(p.mouseX, p.mouseY, currentSize, currentSize);
      }
    };

    saveBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      
      try {
        const dataUrl = pg.elt.toDataURL();
        chrome.storage.local.get(['globalOverlays'], (result) => {
          let currentOverlays = result.globalOverlays || [];
          currentOverlays.push(dataUrl);
          chrome.storage.local.set({ 'globalOverlays': currentOverlays });
        });
      } catch (error) {
        console.error("Fehler beim Speichern des Canvas:", error);
      }
    });
  };

  new p5(sketch, absoluteWrapper);
}

// --- TEXTNOTIZ-LAYER FUNKTION ---
function setupTextNoteLayer(targetElement, textToLoad, loadedIndex) {
  const noteContainer = document.createElement('div');
  noteContainer.className = 'text-note-container';
  
  const textarea = document.createElement('textarea');
  textarea.className = 'text-note-input';
  textarea.placeholder = '';
  textarea.value = textToLoad;
  noteContainer.appendChild(textarea);

  const saveTextBtn = document.createElement('button');
  saveTextBtn.className = 'save-text-btn';
  saveTextBtn.innerText = loadedIndex !== null ? '+' : '✴';
  noteContainer.appendChild(saveTextBtn);

  targetElement.parentNode.insertBefore(noteContainer, targetElement.nextSibling);

  saveTextBtn.addEventListener('click', () => {
    const currentText = textarea.value.trim();
    if (!currentText) return;

    chrome.storage.local.get(['globalTextNotes'], (result) => {
      let currentNotes = result.globalTextNotes || [];
      
      if (loadedIndex !== null) {
        currentNotes[loadedIndex] = currentText;
      } else {
        currentNotes.push(currentText);
        loadedIndex = currentNotes.length - 1; 
        saveTextBtn.innerText = '✴';
      }

      chrome.storage.local.set({ 'globalTextNotes': currentNotes });
    });
  });
}